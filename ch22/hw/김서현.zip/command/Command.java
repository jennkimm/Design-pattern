package ch22.hw.command;

public interface Command {
    public abstract void execute();
}
